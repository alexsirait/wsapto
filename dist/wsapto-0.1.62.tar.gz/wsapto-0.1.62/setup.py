from setuptools import setup, find_packages

setup(
    name="wsapto",  # Nama package Anda
    version="0.1.62",
    author="Alex Sirait",
    author_email="alexsirait1001@gmail.com",
    description="wsapto sooo coolll",
    packages=find_packages(),  # Otomatis menemukan semua subfolder dengan __init__.py
    python_requires=">=3.2",
)
